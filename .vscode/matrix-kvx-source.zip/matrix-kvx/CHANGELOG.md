# Change Log

## [0.3.0] — 2026-05-23

### Added — MatrixScript (`.mtx`) support
- New language `mtx` registered for `.mtx` and `SKILL.mtx`.
- New TextMate grammar at `syntaxes/mtx.tmLanguage.json` covering: `§SECTION` headers, typed slot declarations (`slot target: ArtifactRef`, `enum<a|b|c>`, `Type[]`), block keywords (`on`/`prompt`/`resolve`/`unknown`/`clarify`/`end`), condition identifiers (`verb=`, `confidence<`, `on unknown`), resolve arrow (`<-`), cortex calls (`cortex.find/resolve/context/bundle`), slot paths (`slot.target.prose`), D7 closed verbs, extension verb prefix (`x:…`), MCL domain types (`ArtifactRef`, `Constraint`, `Predicate`, `Unknown`, `PlanDraft`, `SkillRef`, `ToolRef`, `CortexRef`, `SlotPath`, `AssetAmount`, `AgentRef`, `UserRef`), scalar types (`string`, `uint`, `float`, `bool`, `ulid`, `iso8601`, `did`, `sha256`), severity / action / suggestion / failure-reason / seed-policy / determinism closed vocabularies, prompt role keys (`system=`, `user=`, `assistant=`), `matrix://` URIs, `did:method:id` literals, semver, sha256 digests, comparison operators (`<`/`>`/`<=`/`>=`/`!=`/`==`), and **slot interpolation inside strings** (`{prose}`, `{verb}`, `{slots}`, `{unknowns}`, `{cortex.bundle}`, `{slot.target}`, `{slot.target.prose}`).
- New `language-configuration-mtx.json` with indentation rules and folding markers wiring `on`/`prompt`/`unknown`/`clarify` blocks to `end`.
- New `mtx-file.svg` (white Paxeer X) for `.mtx` files and `SKILL.mtx` filename.
- Disambiguation fixes verified via tokenizer smoke test:
  - `did:pax:0x…` recognised as DID literal (not the scalar type `did`).
  - `prompt="…"` inside `clarify` blocks scoped as a kv key (not the `prompt` block keyword).
  - Bare `on unknown` highlights both `on` and the `unknown` condition identifier.

## [0.2.0] — 2026-05-23

### Added
- **Devicon language icon pack** — 77 brand marks shipped via [devicon](https://github.com/devicons/devicon) (MIT).
- 84 file extensions mapped: `.go`, `.rs`, `.ts`, `.tsx`, `.js`, `.jsx`, `.py`, `.sol`, `.html`, `.css`, `.scss`, `.json`, `.yaml`, `.md`, `.toml`, `.sql`, `.graphql`, `.wasm`, `.tf`, `.dart`, `.swift`, `.kt`, `.java`, `.c`, `.cpp`, `.rb`, `.php`, `.lua`, `.hs`, `.ex`, `.clj`, `.jl`, `.ipynb`, etc.
- 73 special filenames mapped: `Dockerfile`, `Cargo.toml`, `go.mod`, `package.json`, `tsconfig.json`, `hardhat.config.ts`, `tailwind.config.js`, `vite.config.ts`, `next.config.js`, `nuxt.config.ts`, `pyproject.toml`, `Gemfile`, `pom.xml`, `build.gradle`, `Makefile`, `CMakeLists.txt`, `README.md`, `LICENSE`, `.gitignore`, `.eslintrc`, etc.
- 66 folder names mapped: `node_modules`, `.git`, `.github`, `.vscode`, `contracts`, `components`, `pages`, `app`, `hooks`, `src`, `dist`, `build`, `target`, `vendor`, `tests`, `docs`, `public`, `migrations`, `kubernetes`, `terraform`, `aws`, etc.
- Dark-theme visibility fix: black-on-transparent brand marks (Rust, GitHub, Next.js, Tauri, Bun, Deno, Remix, Flask, Nuxt, Vercel, Express, Three.js, Jest, Actix, Anaconda, Apple) get their root SVG fill rewritten to `#cccccc` so they render against dark VSCode themes.

### Preserved
- Paxeer-branded slots for `.kvx`, `cortex/`, and `MCL/` continue to take precedence over generic devicon mappings.

## [0.1.0] — 2026-05-23

### Added
- Language registration for `.kvx`, `MATRIX.CTX`, `matrix.ctx`.
- TextMate grammar covering section headers, k=v pairs, status markers, decision/Q-lock/session/phase IDs, `matrix://` URIs, file-line refs, absolute paths, long hex hashes, ISO dates+timestamps, durations, byte sizes, percentages, unicode operators, pipe separators, `>` hierarchy, backticks, comments.
- Icon theme "Matrix / Paxeer Icons":
  - Blue Paxeer X for `.kvx` files
  - White Paxeer X for `cortex/` directories (closed + open)
  - Blue Paxeer X for `MCL/` directories (closed + open)
  - Neutral gray fallback file/folder icons
- Per-language file icon (works even when a different icon theme is active).
- README with install + theme-customization recipe (Paxeer Blue `#004CED` highlights).
